<?php 
 
	

include('../config.php');

		
		if($_SERVER["REQUEST_METHOD"] == "POST")
	{
		$id=$_POST["id"];
			
		$reply=$_POST["msg_reply"];
		
		
	
		$query = "UPDATE outbox_user_messages SET msg_reply ='".$reply."'
		WHERE id='".$id."'
		";

		$result = $conn->query($query);
		if(!$result){
			echo "UPDATE failed: $query <br>" . $conn->error . "<br><br>";
		}else{
		echo	"<script type='text/javascript'>
   alert('Reply Updated');
   window.location = 'messages.php';</script>" ;
	$stmt->close();
	}
	

	
	}//end of if
?>

fffff