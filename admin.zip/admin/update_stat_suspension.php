<?php 
 
	

include('../config.php');



       
				
		if($_SERVER["REQUEST_METHOD"] == "GET")
	{
		$id=$_GET["id"];
			
		$stat= $_GET["status"];
		
		
	
		$query = "UPDATE serv_suspension SET stat ='".$stat."'
		WHERE id='".$id."'
		";

		$result = $conn->query($query);
		if(!$result){
			echo "UPDATE failed: $query <br>" . $conn->error . "<br><br>";
		}else{
		echo	"<script type='text/javascript'>
   alert('Status Updated');
   window.location = 'Suspension.php';</script>" ;
	$stmt->close();
	}
	

	
	}//end of if
?>

fffff