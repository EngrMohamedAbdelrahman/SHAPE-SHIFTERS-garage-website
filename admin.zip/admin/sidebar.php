<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia">
<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<style>
body {
  margin: 0;
font-family: 'Averia Gruesa Libre';font-size: 15px;
    
}

.sidebar {
  margin: 0;
  padding: 0;
  width: 210px;
  background-color: #333333;
  position: fixed;
  height: 100%;
  overflow: auto;

}

.sidebar a {
  display: block;
  color: white;

  padding: 16px;
  text-decoration: none;
}



.sidebar a:hover:not(.active) {
  background-color: #555;
  color: white;
}

div.content {
  margin-left: 200px;
  padding: 1px 16px;
  height: 1000px;
}

@media screen and (max-width: 900px) {
  .sidebar {
    width: 100%;
    height: auto;
    position: relative;
  }
  .sidebar a {float: left;}
  div.content {margin-left: 0;}
}
a.act{
background: linear-gradient(to right, #00C9FF 0%, #92FE9D 100%);
color: black;
border-radius:10px;
}


@media screen and (max-width: 500px) {
  .sidebar a {
    text-align: center;
    float: none;
  }
}

.button {
  background-color: #333333; 
  border: none;
  color: white;
  padding: 15px 15px;
  text-align: left;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}

.button {width: 210px;}

</style>


 <script type="text/javascript">


function Repairs_menu() {
  var x = document.getElementById("Repairs_menu");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}
function Customization_menu() {
  var x = document.getElementById("Customization_menu");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}

function hide(){
document.getElementById("Repairs_menu").style.display = "none";
document.getElementById("Customization_menu").style.display = "none";
}
</script>

</head>
<body onload="hide()">

 <link rel="stylesheet" href="./css/admin.css">
<div class="sidebar" ><b>
 

					<li><a href="index.php"><span class="glyphicon glyphicon-check"></span>Dashboard</a></li>
                

                   <li> <button type="button" class="button " onclick="Repairs_menu()">
                   <span class="glyphicon glyphicon-check"></span>Repairs</button></li>
<ul id="Repairs_menu">

<li> <a href="#" style="color: yellow">Brake Service</a></li>
<li> <a href="#" style="color: yellow">Engine Service</a></li>
<li> <a href="#" style="color: yellow">Cooling Service</a></li>
</ul>
                

<li> <button type="button" class="button " onclick="Customization_menu()"> 
<span class="glyphicon glyphicon-check"></span>Customization</button></li>
                    <ul id="Customization_menu">
<li > <a href="#" style="color: yellow">Paint Service</a></li>
<li> <a href="#" style="color: yellow">Rims Service</a></li>
<li> <a href="#" style="color: yellow">Suspention Service</a></li>
                    </ul>
                    <li><a href="#"><span class="glyphicon glyphicon-check"></span>Home Services</a></li>
                    <li><a href="#"><span class="glyphicon glyphicon-check"></span>Messages</a></li>
                    <li><a href="logout.php"><span class="glyphicon glyphicon-check"></span>Logout</a></li>

</div>
