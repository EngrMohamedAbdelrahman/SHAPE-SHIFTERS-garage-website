


        <?php
 
include('../config.php');  //include connection file
error_reporting(0);  // using to hide undefine undex errors
session_start(); //start temp session until logout/browser closed

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Shape Shifters Garage </title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link rel="stylesheet" href="../css/admin.css">
  <link href="../assets/img/favicon.png" rel="icon">
  <link href="../assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="../assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="../assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="../assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="../assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">


  <link href="../assets/css/style.css" rel="stylesheet">

 
</head>
<body>
  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top ">
    <div class="container d-flex align-items-center justify-content-lg-between">
 <a href="index.php" class="logo me-auto me-lg-0"><img src="assets/img/LOGO.png" alt="" class="img-fluid"></a>
      <h1 class="logo me-auto me-lg-0"><a href="index.php">SHAPE-SHIFTERS <br> GARAGE<span>.</span></a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
     

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="nav-link scrollto active" href="index.php?#hero">Dashboard</a></li>
          
          <li class="dropdown"><a  class="dropdown-toggle" data-toggle="dropdown" href="#">Repairs <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="Brake.php" >Brake Service</a></li>
          <li><a href="Engine.php" >Engine Service</a></li>
          <li><a href="Cooling.php" >Cooling Service</a></li>
        </ul>
        
          <li class="dropdown"><a   class="dropdown-toggle" data-toggle="dropdown" href="#">Customization <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="Paint.php" >Paint Service</a></li>
          <li><a href="Rims.php" >Rims Service</a></li>
          <li><a href="Suspension.php" >Suspension Service</a></li>
        </ul>
          <li><a class="nav-link scrollto " href="Home.php">Home Services</a></li>
          <li><a class="nav-link scrollto " href="admin_add.php">Add Admin</a></li>
          <li><a class="nav-link scrollto" href="messages.php">Messages</a></li>
 
 <?php

						if(!(empty($_SESSION["user_id"]))) // if user is not login
						
							{
												$user_id=$_SESSION["user_id"];
												$user_name=$_SESSION["username"];
								echo  '	
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Welcome : '.$user_name.' <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="admin_data.php?id='.$user_id.'" >Admin info.</a></li>
          
          <li><a href="../logout.php" >Logout</a></li>
		 
        </ul>
      </li>	';		

							}

						?>

  </ul>
   </nav>
   
    </div>
  </header><!-- End Header -->

</body>

</html>