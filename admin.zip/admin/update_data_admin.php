<?php 
 
	

include('../config.php');



       
				
		if($_SERVER["REQUEST_METHOD"] == "POST")
	{
		$user_id=$_POST["user_id"];
			
		$full_name= $_POST["full_name"];
		
		
	
		$query = "UPDATE manage SET full_name ='".$full_name."'
		WHERE id='".$user_id."'
		";

		$result = $conn->query($query);
		if(!$result){
			echo "UPDATE failed: $query <br>" . $conn->error . "<br><br>";
		}else{
		echo	"<script type='text/javascript'>
   alert('Data saved');
   window.location = 'index.php';</script>" ;
	$stmt->close();
	}
	

	
	}//end of if
?>